class animal:
    def hablar (self):
        pass

class perro(animal):
    def hablar(self):
        print('guau')

class gato(animal):
    def hablar(self):
        print('miau')

for animal in perro(), gato():
    animal.hablar()